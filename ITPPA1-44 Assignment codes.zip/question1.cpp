// Question 1: VukaFit Membership Quotation Application
#include <iostream>   
#include <iomanip>    
#include <string>     
using namespace std;  

int main() {  
    const double BASIC_FEE = 220.00;      // monthly fee for Basic Access 
    const double PLUS_FEE = 350.00;       // monthly fee for Active Plus 
    const double COMPLETE_FEE = 480.00;   // monthly fee for Complete Wellness 
    const double ASSESSMENT_FEE = 180.00; // once-off fitness assessment fee
    const double DISCOUNT_3_TO_5 = 0.07; 
    const double DISCOUNT_6 = 0.12;       

    string studentNumber;     
    string studentName;       // stores the full name
    string membershipName;    
    int code;                 // stores the membership code entered
    int months;               // stores the number of months
    char assessChoice;        // stores Y or N for the fitness assessment
    double monthlyFee = 0.0;  // monthly fee for the chosen membership
    double subtotal;          // monthly fee multiplied by months
    double discountRate;      // discount percentage as a decimal
    double discountAmount;    // rand value of the discount
    double assessmentFee;     // assessment fee charged (0 or 180)
    double finalAmount;       // total amount payable

    cout << "VUKAFIT MEMBERSHIP QUOTATION " << endl;  
    cout << "Enter student number: ";                        
    cin >> studentNumber;                                    
    cin.ignore(10000, '\n');                                 
    cout << "Enter full name: ";                             
    getline(cin, studentName);                               

    if (studentNumber.empty() || studentName.empty()) {      
        cout << "ERROR: Student number and name are required." << endl;  
        return 1;                                           
    }                                                        

    cout << "\nMembership options:" << endl;                 
    cout << "1. Basic Access      R220.00" << endl;          
    cout << "2. Active Plus       R350.00" << endl;          
    cout << "3. Complete Wellness R480.00" << endl;          
    cout << "Select membership (1-3): ";                     // prompt for membership code
    if (!(cin >> code) || code < 1 || code > 3) {            // reject non-numbers 
        cout << "ERROR: Invalid membership code. Enter 1, 2 or 3." << endl;  
        return 1;                                            
    }                                                        

    cout << "Enter number of months (1-6): ";                
    if (!(cin >> months) || months < 1 || months > 6) {      
        cout << "ERROR: Months must be between 1 and 6." << endl;  
        return 1;                                            
    }                                                       

    cout << "Add fitness assessment? (Y/N): ";               // prompt for assessment choice
    if (!(cin >> assessChoice)) {                            
        cout << "ERROR: Invalid input." << endl;             
        return 1;                                         
    }                                                        
    assessChoice = toupper(assessChoice);                    
    if (assessChoice != 'Y' && assessChoice != 'N') {        
        cout << "ERROR: Please answer Y or N." << endl;    
        return 1;                                          
    }                                                        

    switch (code) {                                          
        case 1:                                              
            monthlyFee = BASIC_FEE;                         
            membershipName = "Basic Access";               
            break;                                           
        case 2:                                              
            monthlyFee = PLUS_FEE;                           // set Active Plus fee
            membershipName = "Active Plus";                  // set Active Plus name
            break;                                           
        case 3:                                             
            monthlyFee = COMPLETE_FEE;                       // set Complete Wellness fee
            membershipName = "Complete Wellness";            // set Complete Wellness name
            break;                                         
    }                                                     

    subtotal = monthlyFee * months;                          // membership subtotal

    if (months == 6) {                                       
        discountRate = DISCOUNT_6;                           // 12% discount
    } else if (months >= 3) {                                // 3 to 5 months 
        discountRate = DISCOUNT_3_TO_5;                      // 7% discount
    } else {                                                 // 1 or 2 months
        discountRate = 0.0;                                  // no discount
    }                                                        

    discountAmount = subtotal * discountRate;                
    assessmentFee = (assessChoice == 'Y') ? ASSESSMENT_FEE : 0.0;  // add fee only if requested
    finalAmount = subtotal - discountAmount + assessmentFee; // final amount payable

    cout << fixed << setprecision(2);                        // show money with 2 decimals
    cout << "\n========== QUOTATION ==========" << endl;     // quotation heading
    cout << "Student Number    : " << studentNumber << endl; // show student number
    cout << "Student Name      : " << studentName << endl;   // show student name
    cout << "Membership       : " << membershipName << endl; // show membership name
    cout << "Monthly Fee      : R" << monthlyFee << endl;    // show monthly fee
    cout << "Months           : " << months << endl;         // show months
    cout << "Subtotal         : R" << subtotal << endl;      // show subtotal
    cout << "Discount (" << discountRate * 100 << "%): R" << discountAmount << endl;  // show discount
    cout << "Assessment Fee   : R" << assessmentFee << endl; // show assessment fee
    cout << "FINAL AMOUNT     : R" << finalAmount << endl;   // show final amount
    cout << "===============================" << endl;       

    return 0;                                               
}  // end of main
