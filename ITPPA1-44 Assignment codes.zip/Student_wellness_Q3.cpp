// Question 3: VukaFit Daily Check-in Processor
#include <iostream>  
#include <string>  
using namespace std;

int main() {
    const int MAX_ATTEMPTS = 10;     // daily limit of check-in attempts

    int attempts = 0;                // number of attempts processed so far
    int validCount = 0;              // counter
    int invalidCount = 0;            // counter
    int shortCount = 0;              // counter
    int standardCount = 0;           // counter
    int extendedCount = 0;           // counter
    int gymCount = 0;                // counter
    int groupCount = 0;              // counter
    int consultCount = 0;            // counter
    int totalMinutes = 0;            // accumulator
    double average = 0.0;            // average visit duration
    string studentNumber;            // student number for the current check-in
    int activityCode;                // activity code for the current check-in
    int duration;                    // duration in minutes for the current check-in
    char again = 'Y';                // operator's continue answer

    cout << "=== VUKAFIT CHECK-IN SYSTEM ===" << endl;
    cout << "Activities: 1=Gym Floor, 2=Group Class, 3=Wellness Consultation" << endl;  // activity list

    while (attempts < MAX_ATTEMPTS && again == 'Y') {  // stop at 10 attempts or when operator says N
        attempts++;
        cout << "\n--- Check-in " << attempts << " of " << MAX_ATTEMPTS << " ---" << endl;

        cout << "Student number: ";                    // prompt
        cin >> studentNumber;                          // read student number
        cout << "Activity code (1-3): ";               // prompt
        if (!(cin >> activityCode)) {                  // non-numeric input
            cin.clear();                               // reset the error state
            cin.ignore(10000, '\n');
            activityCode = 0;                          // force invalid
        }                                              // end of check
        cout << "Duration in minutes (15-180): ";
        if (!(cin >> duration)) {
            cin.clear();
            cin.ignore(10000, '\n');
            duration = 0;
        }

        if (activityCode < 1 || activityCode > 3) {
            cout << "INVALID: activity code must be 1, 2 or 3." << endl;
            invalidCount++;
        }
        else if (duration < 15 || duration > 180) {  // invalid duration
            cout << "INVALID: duration must be 15 to 180 minutes." << endl;
            invalidCount++;
        }
        else {                                       // check-in is valid
            validCount++;                              // count valid check-in
            totalMinutes += duration;                  // add to total minutes

            if (activityCode == 1) gymCount++;
            else if (activityCode == 2) groupCount++;
            else consultCount++;

            if (duration <= 44) {
                shortCount++;
                cout << "Classification: SHORT VISIT" << endl;
            }
            else if (duration <= 89) {               // 45-89 minutes
                standardCount++;
                cout << "Classification: STANDARD VISIT" << endl;
            }
            else {                                   // 90-180 minutes
                extendedCount++;                       // extended visit
                cout << "Classification: EXTENDED VISIT" << endl;   // show category
            }

            if (duration >= 120) {                     // 120 minutes or more
                cout << "LONG SESSION CHECK" << endl;  // extra warning
            }                                          // end of long session check
        }

        if (attempts < MAX_ATTEMPTS) {                 // only ask if more attempts are allowed
            do {                                       // repeat until Y or N entered
                cout << "Continue? (Y/N): ";
                cin >> again;
                again = toupper(again);                // accept lower case
            } while (again != 'Y' && again != 'N');    // loop while invalid
        }                                              // end of continue prompt
    }

    if (validCount > 0) {
        average = static_cast<double>(totalMinutes) / validCount;
    }

    cout << "\n================ VUKAFIT DAILY CHECK-IN SUMMARY ================" << endl;  // heading
    cout << "Valid Check-ins     : " << validCount << endl;       // valid total
    cout << "Invalid Attempts    : " << invalidCount << endl;     // invalid total
    cout << "Short Visits        : " << shortCount << endl;       // short total
    cout << "Standard Visits     : " << standardCount << endl;    // standard total
    cout << "Extended Visits     : " << extendedCount << endl;    // extended total
    cout << "Gym Floor Visits    : " << gymCount << endl;         // gym total
    cout << "Group Class Visits  : " << groupCount << endl;       // group total
    cout << "Consultations       : " << consultCount << endl;     // consultation total
    cout << "Total Valid Minutes : " << totalMinutes << endl;     // minutes total
    cout << "Average Visit Duration: " << average << " minutes" << endl;  // average
    cout << "================================================================" << endl;

    return 0;
}