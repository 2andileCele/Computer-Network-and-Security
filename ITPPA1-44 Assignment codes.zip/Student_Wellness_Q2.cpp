// Question 2: VukaFit Booking Calculator (modular design with functions)
#include <iostream>   
#include <string>  
using namespace std;

void displaySessionMenu();                          // prints the session menu
double getSessionRate(int sessionCode);             // returns price per participant 
bool validParticipants(int participants);
double calculateSubtotal(double rate, int participants);
double calculateDiscount(double subtotal, int participants);    // 10% discount for 8 or more
double calculateWeekendSurcharge(double amountAfterDiscount, char saturday);  // 15% if Saturday
void displayBookingSummary(string bookingRef, string sessionName,
    int participants, double subtotal,
    double discount, double surcharge,
    double finalTotal);

void displaySessionMenu() {
    cout << "\nSession options:" << endl;
    cout << "1. Yoga Fundamentals  R75" << endl;
    cout << "2. Strength Circuit   R110" << endl;
    cout << "3. Stress Management  R90" << endl;
}

double getSessionRate(int sessionCode) {
    switch (sessionCode) {
    case 1: return 75.0;
    case 2: return 110.0;
    case 3: return 90.0;
    default: return 0.0;
    }
}

bool validParticipants(int participants) {
    return participants >= 1 && participants <= 12;  // valid range is 1 to 12
}

double calculateSubtotal(double rate, int participants) {
    return rate * participants;                      // subtotal before discount
}

double calculateDiscount(double subtotal, int participants) {
    if (participants >= 8) {                         // group of 8 or more
        return subtotal * 0.10;                      // 10% group discount
    }
    return 0.0;                                      // otherwise no discount
}

double calculateWeekendSurcharge(double amountAfterDiscount, char saturday) {
    if (saturday == 'Y') {
        return amountAfterDiscount * 0.15;           // 15% surcharge after the group discount
    }
    return 0.0;                                      // otherwise no surcharge
}

void displayBookingSummary(string bookingRef, string sessionName,
    int participants, double subtotal,
    double discount, double surcharge,
    double finalTotal) {
    double afterDiscount = subtotal - discount;      // amount after the group discount
    cout << "\n======= BOOKING SUMMARY =======" << endl;          // heading
    cout << "Booking Reference : " << bookingRef << endl;        // reference
    cout << "Session           : " << sessionName << endl;       // session name
    cout << "Participants      : " << participants << endl;      // participant count
    cout << "Subtotal          : R" << subtotal << endl;         // subtotal
    cout << "Group Discount    : R" << discount << endl;         // discount
    cout << "After Discount    : R" << afterDiscount << endl;    // after discount
    cout << "Weekend Surcharge : R" << surcharge << endl;        // surcharge
    cout << "FINAL TOTAL       : R" << finalTotal << endl;       // final total
    cout << "Cost Per Person   : R" << finalTotal / participants << endl;  // cost per participant
    cout << "===============================" << endl;
}

int main() {
    string bookingRef;                               // booking reference
    string sessionName;                              // name of chosen session
    int sessionCode = 0;                             // session code entered
    int participants = 0;                            // number of participants
    char saturday = 'N';                             // Saturday Y/N answer
    double rate;                                     // price per participant
    double subtotal, discount, surcharge, finalTotal;  // calculated values

    cout << "=== VUKAFIT BOOKING CALCULATOR ===" << endl;
    cout << "Enter booking reference: ";             // prompt
    cin >> bookingRef;

    do {
        displaySessionMenu();                        // show the menu
        cout << "Select session (1-3): ";
        if (!(cin >> sessionCode)) {                 // non-numeric input
            cin.clear();                             // reset the error state
            cin.ignore(10000, '\n');                 // discard the bad input
            sessionCode = 0;
        }
        rate = getSessionRate(sessionCode);          // look up rate (0 if invalid)
        if (rate == 0.0) {                           // invalid code
            cout << "ERROR: Invalid session code. Try again." << endl;  // message
        }
    } while (rate == 0.0);

    if (sessionCode == 1) sessionName = "Yoga Fundamentals";         // name for code 1
    else if (sessionCode == 2) sessionName = "Strength Circuit";     // name for code 2
    else sessionName = "Stress Management";                          // name for code 3

    do {
        cout << "Enter number of participants (1-12): ";
        if (!(cin >> participants)) {                // non-numeric input
            cin.clear();                             // reset the error state
            cin.ignore(10000, '\n');                 // discard the bad input
            participants = 0;                        // force invalid
        }
        if (!validParticipants(participants)) {
            cout << "ERROR: Participants must be 1 to 12." << endl;
        }                                            // end of error message
    } while (!validParticipants(participants));      // loop while invalid

    do {
        cout << "Is the booking on a Saturday? (Y/N): ";
        cin >> saturday;                             // read answer
        saturday = toupper(saturday);                // accept lower case too
        if (saturday != 'Y' && saturday != 'N') {    // invalid answer
            cout << "ERROR: Please enter Y or N." << endl;  // message
        }                                            // end of error message
    } while (saturday != 'Y' && saturday != 'N');    // loop while invalid

    subtotal = calculateSubtotal(rate, participants);              // calculate subtotal
    discount = calculateDiscount(subtotal, participants);          // calculate group discount
    surcharge = calculateWeekendSurcharge(subtotal - discount, saturday);  // surcharge on discounted amount
    finalTotal = subtotal - discount + surcharge;    // final booking total

    displayBookingSummary(bookingRef, sessionName, participants,   // show the summary
        subtotal, discount, surcharge, finalTotal);

    return 0;
}
