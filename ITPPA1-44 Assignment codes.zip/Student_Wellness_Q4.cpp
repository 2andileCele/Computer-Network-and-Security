// Question 4: VukaFit Weekly Attendance Analytics (arrays)
#include <iostream>   // for cout
#include <string>     // for string
#include <iomanip>

using namespace std;  // use the standard namespace

int main() {  
    const int PROGS = 3;          // number of programmes 
    const int DAYS = 5;           // number of weekdays
    const int THRESHOLD = 40;     // HIGH DEMAND threshold

    string programmes[PROGS] = { "Yoga", "Strength", "Wellness Workshop" };
    string days[DAYS] = { "Mon", "Tue", "Wed", "Thu", "Fri" };               
    int attendance[PROGS][DAYS] = {                // attendance data
        {24, 31, 28, 35, 30},                      // Yoga
        {38, 42, 36, 45, 41},                      // Strength
        {18, 22, 25, 20, 27}                       // Wellness Workshop
    };                                             

    int weeklyTotal[PROGS] = { 0, 0, 0 };            // weekly total per programme
    int dayTotal[DAYS] = { 0, 0, 0, 0, 0 };          // total per weekday across programmes
    int bestDay[PROGS] = { 0, 0, 0 };                // index of highest day per programme
    int grandTotal = 0;                            // total of all 15 values
    int highDemandCount = 0;                       // values at or above threshold
    int busiestDay = 0;                            // index of busiest weekday
    int topProgramme = 0;                          // index of top programme

    cout <<   "=== VUKAFIT WEEKLY ATTENDANCE REPORT ===" << endl;  
    cout <<   left << setw(20) <<  "Programme";        // column header for programme
    for (int d = 0; d < DAYS; d++) {                // loop over weekdays
        cout << setw(14) << days[d];                // print each day name
    }                                              
    cout << endl;                                  

    for (int p = 0; p < PROGS; p++) {              
        cout << left << setw(20) << programmes[p];  // print programme name
        for (int d = 0; d < DAYS; d++) {            // inner loop: each day
            int value = attendance[p][d];           // current attendance value
            weeklyTotal[p] += value;                // add to programme weekly total
            dayTotal[d] += value;                   // add to weekday total
            grandTotal += value;                    // add to grand total
            if (value > attendance[p][bestDay[p]]) {  // new highest day for this programme
                bestDay[p] = d;                     // remember the day index
            }                                       // end of highest-day check
            string cell = to_string(value);         // convert value to text
            if (value >= THRESHOLD) {               // at or above threshold
                cell += " HIGH DEMAND";             // add the indicator
                highDemandCount++;                  // count it
            }                                       // end of threshold check
            cout << setw(14) << cell;               
        }                                         
        cout << endl;                               
    }                                              

    cout << "\n--- Programme Totals and Daily Averages ---" << endl; 
    for (int p = 0; p < PROGS; p++) {               // loop over programmes
        cout << programmes[p] << ": total = " << weeklyTotal[p]         // show total
            << ", daily average = " << static_cast<double>(weeklyTotal[p]) / DAYS << endl;  // show average
        if (weeklyTotal[p] > weeklyTotal[topProgramme]) {               // higher than current top
            topProgramme = p;                    
        }                                       
    }                                             

    cout << "\n--- Highest Attendance Day per Programme ---" << endl;   
    for (int p = 0; p < PROGS; p++) {               // loop over programmes
        cout << programmes[p] << ": " << days[bestDay[p]]               // show best day
            << " (" << attendance[p][bestDay[p]] << ")" << endl;       // show its value
    }                                             

    cout << "\n--- Weekday Totals Across All Programmes ---" << endl;  
    for (int d = 0; d < DAYS; d++) {                // loop over weekdays
        cout << days[d] << ": " << dayTotal[d] << endl;                 // show weekday total
        if (dayTotal[d] > dayTotal[busiestDay]) {   // higher than current busiest
            busiestDay = d;                         // update busiest day
        }                                       
    }                                               

    cout << "\nBusiest weekday: " << days[busiestDay]                   // show busiest day
        << " (" << dayTotal[busiestDay] << ")" << endl;                // and its total
    cout << "Highest weekly attendance programme: " << programmes[topProgramme]  // show top programme
        << " (" << weeklyTotal[topProgramme] << ")" << endl;           // and its total
    cout << "Values of " << THRESHOLD << " or greater (HIGH DEMAND): " << highDemandCount << endl;  // count
    cout << "Grand total: " << grandTotal << endl;                      // grand total
    cout << "Overall average: " << static_cast<double>(grandTotal) / (PROGS * DAYS) << endl;  // overall average

    return 0;                                    
}  
